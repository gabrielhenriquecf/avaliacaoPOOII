package br.ifsuldeminas.edu.gui;

public enum EPayable {
	
	Cliente

}
