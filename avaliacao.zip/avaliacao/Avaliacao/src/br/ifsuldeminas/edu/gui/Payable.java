package br.ifsuldeminas.edu.gui;

public interface Payable {

	
	

}
