package br.ifsuldeminas.edu.gui;

//import java.awt.List;
import java.util.ArrayList;

//import br.edu.ifsuldeminas.controller.ControllerPayable;
//import br.edu.ifsuldeminas.dao.PayableDao;
//import br.edu.ifsuldeminas.dao.factory.PayableFactory;
//import br.edu.ifsuldeminas.enums.EPayable;
//import br.edu.ifsuldeminas.model.Payable;

public class ControllerSalario {
	
	/* padrão de projeto - singleton */
	private static ControllerSalario instance = null;
	
	/* Arraylist */
	private ArrayList<Payable> listCliente = new ArrayList<Payable>();//List
	
	private ControllerSalario() {}
	
	public static ControllerSalario getInstance() {
		if(instance == null) {
			instance = new ControllerSalario();
		}
		
		return instance;
	}
	
	
	public boolean Add(Cliente c) {
		//listCliente.add(c);
		PayableFactory factory = new PayableFactory();
		PayableDao dao = factory.getDaoCliente();
		boolean resposta = dao.saveCliente(c);
		return resposta;
	}
	
	
	
	public ArrayList<Payable> ListAll() {
		
		listCliente.clear();
		ArrayList<Payable> listTemp = null;
		PayableFactory factory = new PayableFactory();
		
		for(EPayable objeto : EPayable.values()) {
			PayableDao dao = factory.getDaoCliente(objeto); 
			listTemp = dao.getAllCliente();
			if(listTemp != null) {
				listCliente.addAll(listTemp);
				listTemp.clear();
			}
		}
			
		return listCliente;  
	}
	
//	public Payable getPayable(int id, EPayable tipo) {
//		
//		PayableFactory factory = new PayableFactory();
//		PayableDao dao = factory.getDaoPayable(tipo);
//		Payable resposta = dao.getPayable(id);
//		return resposta;
//	}
//
//	public boolean Update(Payable p) {
//		PayableFactory factory = new PayableFactory();
//		PayableDao dao = factory.getDaoPayble(p);
//		boolean resposta = dao.updatePayable(p);
//		return resposta;
//	}
//
//	public boolean Delete(Payable p) {
//		PayableFactory factory = new PayableFactory();
//		PayableDao dao = factory.getDaoPayble(p);
//		boolean resposta = dao.deletePayable(p);
//		return resposta;
//	
//	}

}
