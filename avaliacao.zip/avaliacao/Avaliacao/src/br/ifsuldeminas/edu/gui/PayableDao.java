package br.ifsuldeminas.edu.gui;

import java.util.ArrayList;
//import java.util.List;

//import br.edu.ifsuldeminas.model.Payable;

public interface PayableDao {
	
	public boolean saveCliente(Cliente cliente) ;
	public boolean deleteCliente(Cliente c);
	public boolean updateCliente(Cliente cliente);
	public Cliente getCliente(int id);
	public ArrayList<Payable> getAllCliente();

}
