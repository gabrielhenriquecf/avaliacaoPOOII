package br.ifsuldeminas.edu.gui;

import java.awt.EventQueue;

import javax.swing.JFrame;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.KeyStroke;
import javax.swing.JButton;
import javax.swing.ImageIcon;
import javax.swing.JMenuBar;
import javax.swing.JMenu;
import java.awt.Dimension;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.LayoutStyle.ComponentPlacement;

//import br.edu.ifsuldeminas.view.MainGUI;
//import br.edu.ifsuldeminas.view.report.ReportEmployeeGUI;

//import br.edu.ifsuldeminas.controller.ControllerPayable;


public class gui {

	private JFrame frmInserirClientes;
	private JTextField textFieldNome; // mudar
	private JTextField textFieldSobrenome;
	private JTextField textFieldCpf;
	private JTextField textFieldDataNascimento;
	private JTextField textFieldSalario;
	private JTextField textFieldRg;
	private JTextField textFieldTelefone; //at� aqui

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					gui window = new gui();
					window.frmInserirClientes.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the application.
	 */
	public gui() {
		initialize();
	}

	/**
	 * Initialize the contents of the frame.
	 */
	private void initialize() {
		frmInserirClientes = new JFrame();
		frmInserirClientes.setMinimumSize(new Dimension(300, 330));
		frmInserirClientes.setTitle("Inserir Clientes");
		frmInserirClientes.setBounds(100, 100, 300, 339);
		frmInserirClientes.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		JLabel lblNome = new JLabel("Nome:");
		
		JLabel lblNewLabel = new JLabel("Sobrenome:");
		
		JLabel lblNewLabel_1 = new JLabel("CPF:");
		
		JLabel lblNewLabel_2 = new JLabel("DATA DE NASCIMENTO:");
		
		JLabel lblNewLabel_3 = new JLabel("SAL\u00C1RIO:");
		
		JLabel lblNewLabel_4 = new JLabel("RG:");
		
		JLabel lblNewLabel_5 = new JLabel("TELEFONE:");
		
		textFieldNome = new JTextField();
		textFieldNome.setColumns(10);
		
		textFieldSobrenome = new JTextField();
		textFieldSobrenome.setColumns(10);
		
		textFieldCpf = new JTextField();
		textFieldCpf.setColumns(10);
		
		textFieldDataNascimento = new JTextField();
		textFieldDataNascimento.setColumns(10);
		
		textFieldSalario = new JTextField();
		textFieldSalario.setColumns(10);
		
		textFieldRg = new JTextField();
		textFieldRg.setColumns(10);
		
		textFieldTelefone = new JTextField();
		textFieldTelefone.setColumns(10);
		
		JButton btnIncluir = new JButton("Registrar");
		//btnIncluir.setEnabled(false);
		
		btnIncluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/* recuperar os dados do JTextField */
				String nome = textFieldNome.getText();
				String sobrenome = textFieldSobrenome.getText();
				String cpf = textFieldCpf.getText();
				String dataNascimento = textFieldDataNascimento.getText();//alterar depois texto para data
				String salario = textFieldSalario.getText();
				String rg = textFieldRg.getText();
				String telefone = textFieldTelefone.getText();//if se for null
				
				double salary = 0;
				try {
					salary = Double.parseDouble(salario);
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Sal�rio inv�lido");
					return;
				}
				
		
				/* Criar um objeto do tipo Cliente */
				Cliente cliente = new Cliente(nome, sobrenome, cpf, dataNascimento, salary, rg, telefone);

				/* Adicionar na minha Lista */
				boolean resposta = ControllerSalario.getInstance().Add(cliente);

				if(resposta == true) {
					JOptionPane.showMessageDialog(null,  cliente.toString() + "\nInclus�o com sucesso !", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null,  cliente.toString() + "\nOcorreu um erro !", "Erro", JOptionPane.ERROR_MESSAGE);
				}
			
				/* Limpar o JTexfield */
				textFieldNome.setText("");
				textFieldSobrenome.setText("");
				textFieldCpf.setText("");
				textFieldDataNascimento.setText("");
				textFieldSalario.setText("");
				textFieldRg.setText("");
				textFieldTelefone.setText("");

				
			}
		});
		
		JLabel lblNewLabel_6 = new JLabel("New label");
		lblNewLabel_6.setIcon(new ImageIcon(gui.class.getResource("/imagem/Capturar.PNG")));
		GroupLayout groupLayout = new GroupLayout(frmInserirClientes.getContentPane());
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(10)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNome, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
							.addGap(84)
							.addComponent(textFieldNome, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 119, GroupLayout.PREFERRED_SIZE)
							.addGap(11)
							.addComponent(textFieldSobrenome, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
							.addGap(84)
							.addComponent(textFieldCpf, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 139, GroupLayout.PREFERRED_SIZE)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(130)
							.addComponent(textFieldDataNascimento, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_3, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
							.addGap(42)
							.addComponent(textFieldSalario, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
							.addComponent(lblNewLabel_4, GroupLayout.PREFERRED_SIZE, 46, GroupLayout.PREFERRED_SIZE)
							.addGap(84)
							.addComponent(textFieldRg, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
						.addGroup(groupLayout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(lblNewLabel_5, GroupLayout.PREFERRED_SIZE, 88, GroupLayout.PREFERRED_SIZE)
							.addGap(42)
							.addComponent(textFieldTelefone, GroupLayout.DEFAULT_SIZE, 134, Short.MAX_VALUE))
						.addGroup(Alignment.TRAILING, groupLayout.createSequentialGroup()
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnIncluir, GroupLayout.PREFERRED_SIZE, 128, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 36, Short.MAX_VALUE)
							.addComponent(lblNewLabel_6, GroupLayout.PREFERRED_SIZE, 100, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)))
					.addGap(10))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(25)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(3)
							.addComponent(lblNome))
						.addComponent(textFieldNome, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(5)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(3)
							.addComponent(lblNewLabel))
						.addComponent(textFieldSobrenome, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(5)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(3)
							.addComponent(lblNewLabel_1))
						.addComponent(textFieldCpf, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(5)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(3)
							.addComponent(lblNewLabel_2))
						.addComponent(textFieldDataNascimento, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(5)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(3)
							.addComponent(lblNewLabel_3))
						.addComponent(textFieldSalario, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(5)
					.addGroup(groupLayout.createParallelGroup(Alignment.LEADING)
						.addGroup(groupLayout.createSequentialGroup()
							.addGap(3)
							.addComponent(lblNewLabel_4))
						.addComponent(textFieldRg, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
					.addGap(5)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(textFieldTelefone, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_5))
					.addGap(21)
					.addGroup(groupLayout.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel_6, GroupLayout.PREFERRED_SIZE, 47, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnIncluir, GroupLayout.PREFERRED_SIZE, 44, GroupLayout.PREFERRED_SIZE))
					.addGap(3))
		);
		frmInserirClientes.getContentPane().setLayout(groupLayout);
		
		JMenuBar menuBar = new JMenuBar();
		frmInserirClientes.setJMenuBar(menuBar);
		
		JMenu mnNewMenuFile = new JMenu("File");
		menuBar.add(mnNewMenuFile);
		
		JMenuItem mntmMenuItemSair = new JMenuItem("Sair");
		mnNewMenuFile.add(mntmMenuItemSair);
		mntmMenuItemSair.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				System.exit(0);
			}
		});
		mntmMenuItemSair.setAccelerator(KeyStroke.getKeyStroke(KeyEvent.VK_F4, InputEvent.ALT_MASK));
		mntmMenuItemSair.setIcon(new ImageIcon(gui.class.getResource("/img/Exit_Plain_Blue.png")));
		mnNewMenuFile.add(mntmMenuItemSair);
		
		JMenu mnNewMenuCliente = new JMenu("Cliente");
		menuBar.add(mnNewMenuCliente);
		
		JMenuItem mntmNewMenuItemUpdate = new JMenuItem("Update");
		mnNewMenuCliente.add(mntmNewMenuItemUpdate);
		
		JMenuItem mntmNewMenuItemDelete = new JMenuItem("Delete");
		mnNewMenuCliente.add(mntmNewMenuItemDelete);
		
		JMenu mnNewMenuLista = new JMenu("Lista");
		menuBar.add(mnNewMenuLista);
		
		JMenuItem mntmMenuItemListar = new JMenuItem("Listar clientes");
		mnNewMenuLista.add(mntmMenuItemListar);
		mntmMenuItemListar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				ReportClienteGUI reportGui = new ReportClienteGUI();
				reportGui.setLocationRelativeTo(null);
				reportGui.setVisible(true);
				
			}
		});
		mntmMenuItemListar.setIcon(new ImageIcon(gui.class.getResource("/img/attached16x16.png")));
		mnNewMenuLista.add(mntmMenuItemListar);
	}}








