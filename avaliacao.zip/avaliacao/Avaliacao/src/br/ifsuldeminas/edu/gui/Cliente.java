package br.ifsuldeminas.edu.gui;

public class Cliente implements Payable{

	private String nome;
	private String sobrenome;
	private String cpf;
	private String dataNascimento;
	private double salario;
	private String telefone;
	private int id;
	
	public Cliente(String nome, String sobrenome, String cpf, String dataNascimento, double salario, String rg,
			String telefone) {
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.cpf = cpf;
		this.dataNascimento = dataNascimento;
		this.salario = salario;
		this.telefone = telefone;
	}


	public Cliente(int id, String nome, String sobrenome, String cpf, String dataNascimento, double salario,
			String rg, String telefone) {
		// TODO Auto-generated constructor stub
		this.id = id;
		this.nome = nome;
		this.sobrenome = sobrenome;
		this.cpf = cpf;
		this.dataNascimento = dataNascimento;
		this.salario = salario;
		this.telefone = telefone;
	}


	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getNome() {
		return nome;
	}


	public void setNome(String nome) {
		this.nome = nome;
	}


	public String getSobrenome() {
		return sobrenome;
	}


	public void setSobrenome(String sobrenome) {
		this.sobrenome = sobrenome;
	}


	public String getCpf() {
		return cpf;
	}


	public void setCpf(String cpf) {
		this.cpf = cpf;
	}


	public String getDataNascimento() {
		return dataNascimento;
	}


	public void setDataNascimento(String dataNascimento) {
		this.dataNascimento = dataNascimento;
	}
	
	public double getSalario() {
		return salario;
	}


	public void setSalario(double salario) {
		this.salario = salario;
	}


	public String getTelefone() {
		return telefone;
	}


	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String toString() {
		String s = String.format("Cadastro realizado com sucesso de %s %s com CPF %s", getNome(), getSobrenome(), getCpf());
		return s;
	}
	
}
