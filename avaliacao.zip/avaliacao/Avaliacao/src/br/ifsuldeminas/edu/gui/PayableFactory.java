package br.ifsuldeminas.edu.gui;

//import br.edu.ifsuldeminas.dao.employee.SalariedEmployeeDaoImpl;

//import br.edu.ifsuldeminas.dao.PayableDao;
//import br.edu.ifsuldeminas.model.Payable;

public class PayableFactory {
	
	public PayableDao getDaoCliente() {
		
		new ClienteDaoImpl();
		
		return null;
				
	}

	public PayableDao getDaoCliente(EPayable tipo) {
		switch(tipo) {
		 
		case Cliente:
			return (PayableDao) new ClienteDaoImpl();
			
		default: 
			return null;
		}
		
	}

}