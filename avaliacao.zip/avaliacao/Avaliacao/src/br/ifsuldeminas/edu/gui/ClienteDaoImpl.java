package br.ifsuldeminas.edu.gui;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
//import java.util.List;

//import br.edu.ifsuldeminas.connection.ConnectFactory;
//import br.edu.ifsuldeminas.model.Payable;
//import br.edu.ifsuldeminas.model.SalariedEmployee;
//import br.ifsuldeminas.edu.br.utils.Utils;
//import br.edu.ifsuldeminas.dao.PayableDao;


public class ClienteDaoImpl implements PayableDao{

	@Override
	public boolean saveCliente(Cliente cliente) {
		
		Connection connection = null;

		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instru��o SQL */
			String query = "insert into clientes (nome,sobrenome,cpf,data_nascimento,salario,rg,telefone) values(?, ?, ?, ?, ?, ?, ?)";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			
			prepare.setString(1, cliente.getNome());
			prepare.setString(2, cliente.getSobrenome());
			prepare.setString(3, cliente.getCpf().replace(".", "").replace("-", ""));
			prepare.setString(4, cliente.getDataNascimento());
			prepare.setDouble(5, cliente.getSalario());
			prepare.setString(6, cliente.getClass().getSimpleName());

			prepare.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}

		return sucesso;
	}

	@Override
	public boolean deleteCliente(Cliente c) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public boolean updateCliente(Cliente cliente) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public Cliente getCliente(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	@Override
	public ArrayList<Payable> getAllCliente() {
		
		ArrayList<Payable> listCliente = new ArrayList<Payable>();//List
		Connection connection = null;
		Statement st = null;
		
		try {
			connection = ConnectFactory.createConnection();
			
			String query = "SELECT id, nome, sobrenome, cpf, data_nascimento, salario, rg, telefone FROM clientes";
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String nome = rs.getString("nome");
				String sobrenome = rs.getString("sobrenome");
				String cpf = Utils.formatarString("###.###.###-##", rs.getString("cpf"));
				String dataNascimento = rs.getString("data_nascimento");
				double salario = rs.getDouble("salario");
				String rg = rs.getString("rg");
				String telefone = rs.getString("telefone");
				listCliente.add(new Cliente(id, nome,sobrenome,cpf,dataNascimento,salario,rg,telefone));
				
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return listCliente;
	
	}

}
