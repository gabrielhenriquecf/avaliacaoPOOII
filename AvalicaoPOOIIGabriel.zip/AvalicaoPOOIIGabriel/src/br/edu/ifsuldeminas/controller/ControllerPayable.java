package br.edu.ifsuldeminas.controller;

import java.util.ArrayList;
import java.util.List;

import br.edu.ifsuldeminas.dao.PayableDao;
import br.edu.ifsuldeminas.dao.employee.HourlyEmployeeDaoImpl;
import br.edu.ifsuldeminas.dao.employee.SalariedEmployeeDaoImpl;
import br.edu.ifsuldeminas.dao.factory.PayableFactory;
import br.edu.ifsuldeminas.enums.EPayable;
import br.edu.ifsuldeminas.model.Employee;
import br.edu.ifsuldeminas.model.Payable;
import br.edu.ifsuldeminas.model.SalariedEmployee;

public class ControllerPayable {
	
	/* padrão de projeto - singleton */
	private static ControllerPayable instance = null;
	
	/* Arraylist */
	private List<Payable> listPayable = new ArrayList<Payable>();
	
	private ControllerPayable() {}
	
	public static ControllerPayable getInstance() {
		if(instance == null) {
			instance = new ControllerPayable();
		}
		
		return instance;
	}
	
	
	public boolean Add(Payable p) {
		//listPayable.add(p);
		PayableFactory factory = new PayableFactory();
		PayableDao dao = factory.getDaoPayble(p);
		boolean resposta = dao.savePayable(p);
		return resposta;
	}
	
	
	
	public List<Payable> ListAll() {
		
		listPayable.clear();
		List<Payable> listTemp = null;
		PayableFactory factory = new PayableFactory();
		
		for(EPayable objeto : EPayable.values()) {
			PayableDao dao = factory.getDaoPayable(objeto); 
			listTemp = dao.getAllPayable();
			if(listTemp != null) {
				listPayable.addAll(listTemp);
				listTemp.clear();
			}
		}
			
		return listPayable;  
	}
	
	public List<Payable> ListByType(EPayable tipo){
		listPayable.clear();
		PayableFactory factory = new PayableFactory();
		PayableDao dao = factory.getDaoPayable(tipo); 
		listPayable = dao.getAllPayable();
						
		return listPayable; 
	}
	
	
	public Payable getPayable(int id, EPayable tipo) {
		
		PayableFactory factory = new PayableFactory();
		PayableDao dao = factory.getDaoPayable(tipo);
		Payable resposta = dao.getPayable(id);
		return resposta;
	}

	public boolean Update(Payable p) {
		PayableFactory factory = new PayableFactory();
		PayableDao dao = factory.getDaoPayble(p);
		boolean resposta = dao.updatePayable(p);
		return resposta;
	}

	public boolean Delete(Payable p) {
		PayableFactory factory = new PayableFactory();
		PayableDao dao = factory.getDaoPayble(p);
		boolean resposta = dao.deletePayable(p);
		return resposta;
	
	}

}
