package br.edu.ifsuldeminas.dao.invoice;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import br.edu.ifsuldeminas.connection.ConnectFactory;
import br.edu.ifsuldeminas.dao.PayableDao;
import br.edu.ifsuldeminas.model.Invoice;
import br.edu.ifsuldeminas.model.Payable;
import br.edu.ifsuldeminas.model.SalariedEmployee;
import br.ifsuldeminas.edu.br.utils.Utils;

public class InvoiceDaoImpl implements PayableDao {

	@Override
	public boolean savePayable(Payable payable) {
		Connection connection = null;
		Invoice invoice = (Invoice) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			String query = "insert into invoice (part_number,part_description,quantity,price_per_item) values(?, ?, ?, ?)";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			
			prepare.setString(1, invoice.getPartNumber());
			prepare.setString(2, invoice.getPartDescription());
			prepare.setInt(3, invoice.getQuantity());
			prepare.setDouble(4, invoice.getPricePerItem());
			
			prepare.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public boolean deletePayable(Payable payable) {

		Connection connection = null;
		Invoice invoice = (Invoice) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			
			String query = "DELETE FROM invoice WHERE id = ?";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setInt(1, invoice.getId());
			prepare.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public boolean updatePayable(Payable payable) {
	
		Connection connection = null;
		Invoice invoice = (Invoice) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			
			String query = "UPDATE invoice set part_number=?, part_description=?,quantity=?, price_per_item=? WHERE id = ?";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			
			prepare.setString(1, invoice.getPartNumber());
			prepare.setString(2, invoice.getPartDescription());
			prepare.setInt(3, invoice.getQuantity());
			prepare.setDouble(4, invoice.getPricePerItem());
			prepare.setInt(5, invoice.getId());
			
			prepare.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public Payable getPayable(int id) {
	
		Invoice invoice = null;
		Connection connection = null;
		Statement st = null;
		
		try {
			connection = ConnectFactory.createConnection();
			
			String query = "SELECT id, part_number, part_description, quantity, price_per_item FROM invoice where id = " + id ;
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				
				int identifier = rs.getInt("id");
				String part_number = rs.getString("part_number");
				String part_description = rs.getString("part_description");
				int quantity = rs.getInt("quantity");
				double price_per_item = rs.getDouble("price_per_item");
			
				invoice = new Invoice(identifier, part_number, part_description, quantity, price_per_item);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return invoice;
	}

	@Override
	public List<Payable> getAllPayable() {
		List<Payable> listPayable = new ArrayList<Payable>();
		Connection connection = null;
		Statement st = null;
		
		try {
			connection = ConnectFactory.createConnection();
			
			String query = "SELECT id, part_number, part_description, quantity, price_per_item FROM invoice" ;
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String part_number = rs.getString("part_number");
				String part_description = rs.getString("part_description");
				int quantity = rs.getInt("quantity");
				double price_per_item = rs.getDouble("price_per_item");
			
				listPayable.add(new Invoice(id, part_number, part_description, quantity, price_per_item));
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return listPayable;
	}

}
