package br.edu.ifsuldeminas.dao.employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import br.edu.ifsuldeminas.connection.ConnectFactory;
import br.edu.ifsuldeminas.dao.PayableDao;
import br.edu.ifsuldeminas.model.HourlyEmployee;
import br.edu.ifsuldeminas.model.Payable;
import br.edu.ifsuldeminas.model.SalariedEmployee;
import br.ifsuldeminas.edu.br.utils.Utils;


public class HourlyEmployeeDaoImpl implements PayableDao {

	@Override
	public boolean savePayable(Payable payable) {
		
		Connection connection = null;
		HourlyEmployee employee = (HourlyEmployee) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			String query = "insert into hourly_employee (first_name,last_name,cpf,wage,hours,object_type) values(?, ?, ?, ?, ?,?)";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			
			prepare.setString(1, employee.getFirstName());
			prepare.setString(2, employee.getLastName());
			prepare.setString(3, employee.getCpf().replace(".", "").replace("-", ""));
			prepare.setDouble(4, employee.getWage());
			prepare.setDouble(5, employee.getHours());
			prepare.setString(6, employee.getClass().getSimpleName());
			
			prepare.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public boolean deletePayable(Payable payable) {
		Connection connection = null;
		HourlyEmployee employee = (HourlyEmployee) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			
			String query = "DELETE FROM hourly_employee WHERE id = ?";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setInt(1, employee.getId());
			prepare.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public boolean updatePayable(Payable payable) {
		Connection connection = null;
		HourlyEmployee employee = (HourlyEmployee) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			
			String query = "UPDATE hourly_employee set first_name=?, last_name=?,cpf=?, wage=?, hours=? WHERE id = ?";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			
			prepare.setString(1, employee.getFirstName());
			prepare.setString(2, employee.getLastName());
			prepare.setString(3, employee.getCpf().replace(".", "").replace("-", ""));
			prepare.setDouble(4, employee.getWage());
			prepare.setDouble(5, employee.getHours());
			prepare.setInt(6, employee.getId());
			
			prepare.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public Payable getPayable(int identifier) {
		Connection connection = null;
		Statement st = null;
		HourlyEmployee hourlyEmployee = null;
	
		
		try {
			connection = ConnectFactory.createConnection();
			
			String query = "SELECT id, first_name, last_name, cpf, wage, hours FROM hourly_employee WHERE id = " + identifier;
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String cpf = Utils.formatarString("###.###.###-##", rs.getString("cpf"));
				double wage = rs.getDouble("wage");
				double hours = rs.getDouble("hours");
				hourlyEmployee = new HourlyEmployee(id, firstName,lastName,cpf,wage,hours);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return hourlyEmployee;
	
	}

	@Override
	public List<Payable> getAllPayable() {
		List<Payable> listPayable = new ArrayList<Payable>();
		Connection connection = null;
		Statement st = null;
		
		try {
			connection = ConnectFactory.createConnection();
			
			String query = "SELECT id, first_name, last_name, cpf, wage,hours FROM hourly_employee" ;
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String cpf = Utils.formatarString("###.###.###-##", rs.getString("cpf"));
				double wage = rs.getDouble("wage");
				double hours = rs.getDouble("hours");
				listPayable.add(new HourlyEmployee(id, firstName,lastName,cpf,wage,hours));
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return listPayable;
	}

}
