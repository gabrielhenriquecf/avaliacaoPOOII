package br.edu.ifsuldeminas.dao.employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;

import javax.swing.text.MaskFormatter;

import br.edu.ifsuldeminas.connection.ConnectFactory;
import br.edu.ifsuldeminas.dao.PayableDao;
import br.edu.ifsuldeminas.model.Payable;
import br.edu.ifsuldeminas.model.SalariedEmployee;
import br.ifsuldeminas.edu.br.utils.Utils;

public class SalariedEmployeeDaoImpl implements PayableDao {

	@Override
	public boolean savePayable(Payable payable) {
	
		Connection connection = null;
		SalariedEmployee employee = (SalariedEmployee) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			String query = "insert into salaried_employee (nome,sobrenome,cpf,data_nascimento,salario,rg,telefone) values(?, ?, ?, ?, ?)";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			
			prepare.setString(1, employee.getNome());
			prepare.setString(2, employee.getLastName());
			prepare.setString(3, employee.getCpf().replace(".", "").replace("-", ""));
			prepare.setDouble(4, employee.getWeeklySalary());
			prepare.setString(5, employee.getClass().getSimpleName());
			
			prepare.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public boolean deletePayable(Payable payable) {
		Connection connection = null;
		SalariedEmployee employee = (SalariedEmployee) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			
			String query = "DELETE FROM salaried_employee WHERE id = ?";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setInt(1, employee.getId());
			prepare.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
		
	}

	@Override
	public boolean updatePayable(Payable payable) {
		Connection connection = null;
		SalariedEmployee employee = (SalariedEmployee) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			
			String query = "UPDATE salaried_employee set first_name=?, last_name=?,cpf=?, weekly_salary=? WHERE id = ?";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			
			prepare.setString(1, employee.getFirstName());
			prepare.setString(2, employee.getLastName());
			prepare.setString(3, employee.getCpf().replace(".", "").replace("-", ""));
			prepare.setDouble(4, employee.getWeeklySalary());
			prepare.setInt(5, employee.getId());
			
			prepare.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public Payable getPayable(int identifier) {
		
		Connection connection = null;
		Statement st = null;
		SalariedEmployee salariedEmployee = null;
	
		
		try {
			connection = ConnectFactory.createConnection();
			
			String query = "SELECT id, first_name, last_name, cpf, weekly_salary FROM salaried_employee WHERE id = " + identifier;
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String cpf = Utils.formatarString("###.###.###-##", rs.getString("cpf"));
				double weeklySalaried = rs.getDouble("weekly_salary");
				salariedEmployee = new SalariedEmployee(id, firstName,lastName,cpf,weeklySalaried);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return salariedEmployee;
	
	}

	@Override
	public List<Payable> getAllPayable() {
	
		List<Payable> listPayable = new ArrayList<Payable>();
		Connection connection = null;
		Statement st = null;
		
		try {
			connection = ConnectFactory.createConnection();
			
			String query = "SELECT id, first_name, last_name, cpf, weekly_salary FROM salaried_employee" ;
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String cpf = Utils.formatarString("###.###.###-##", rs.getString("cpf"));
				double weeklySalaried = rs.getDouble("weekly_salary");
				listPayable.add(new SalariedEmployee(id, firstName,lastName,cpf,weeklySalaried));
				
			}
			
			
		} catch (SQLException e) {
			e.printStackTrace();
			return null;
		}
		
		return listPayable;
	
	}

}
