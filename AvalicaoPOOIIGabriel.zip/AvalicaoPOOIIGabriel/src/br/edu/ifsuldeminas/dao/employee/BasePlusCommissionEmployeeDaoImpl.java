package br.edu.ifsuldeminas.dao.employee;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import br.edu.ifsuldeminas.connection.ConnectFactory;
import br.edu.ifsuldeminas.dao.PayableDao;
import br.edu.ifsuldeminas.model.BasePlusCommissionEmployee;
import br.edu.ifsuldeminas.model.Payable;
import br.ifsuldeminas.edu.br.utils.Utils;

public class BasePlusCommissionEmployeeDaoImpl implements PayableDao{

	@Override
	public boolean savePayable(Payable payable) {
		Connection connection = null;
		BasePlusCommissionEmployee employee = (BasePlusCommissionEmployee) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			String query = "insert into baseplus_commission_employee (first_name,last_name,cpf,gross_sales,commission_rate,base_salary, object_type) values(?, ?, ?, ?, ?,?,?)";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			
			prepare.setString(1, employee.getFirstName());
			prepare.setString(2, employee.getLastName());
			prepare.setString(3, employee.getCpf().replace(".", "").replace("-", ""));
			prepare.setDouble(4, employee.getGrossSales());
			prepare.setDouble(5, employee.getCommissionRate());
			prepare.setDouble(6, employee.getBaseSalary());
			prepare.setString(7, employee.getClass().getSimpleName());
			
			prepare.execute();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public boolean deletePayable(Payable payable) {
		Connection connection = null;
		BasePlusCommissionEmployee employee = (BasePlusCommissionEmployee) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			
			String query = "DELETE FROM baseplus_commission_employee WHERE id = ?";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			prepare.setInt(1, employee.getId());
			prepare.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public boolean updatePayable(Payable payable) {
		Connection connection = null;
		BasePlusCommissionEmployee employee = (BasePlusCommissionEmployee) payable;
		boolean sucesso = true;
		
		try {
			connection = ConnectFactory.createConnection();
			
			/* preparar a instrução SQL */
			
			String query = "UPDATE baseplus_commission_employee set first_name=?, last_name=?,cpf=?, gross_sales=?,commission_rate=?,base_salary=? WHERE id = ?";

			/* preencher os dados na query */
			PreparedStatement prepare = connection.prepareStatement(query);
			
			prepare.setString(1, employee.getFirstName());
			prepare.setString(2, employee.getLastName());
			prepare.setString(3, employee.getCpf().replace(".", "").replace("-", ""));
			prepare.setDouble(4, employee.getGrossSales());
			prepare.setDouble(5, employee.getCommissionRate());
			prepare.setDouble(6, employee.getBaseSalary());
			prepare.setInt(7, employee.getId());
			
			prepare.executeUpdate();
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			sucesso = false;
		} finally {
			try {
				connection.close();
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		return sucesso;
	}

	@Override
	public Payable getPayable(int identifier) {
		Connection connection = null;
		Statement st = null;
		BasePlusCommissionEmployee baseCommissionEmployee = null;
	
		
		try {
			connection = ConnectFactory.createConnection();
			
			String query = "SELECT id, first_name, last_name, cpf, gross_sales, commission_rate,base_salary FROM baseplus_commission_employee WHERE id = " + identifier;
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String cpf = Utils.formatarString("###.###.###-##", rs.getString("cpf"));
				double gross_sales = rs.getDouble("gross_sales");
				double commission_rate = rs.getDouble("commission_rate");
				double base_salary = rs.getDouble("base_salary");
				baseCommissionEmployee = new BasePlusCommissionEmployee(id, firstName,lastName,cpf,gross_sales,commission_rate,base_salary);
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return baseCommissionEmployee;
	}

	@Override
	public List<Payable> getAllPayable() {
		List<Payable> listPayable = new ArrayList<Payable>();
		Connection connection = null;
		Statement st = null;
		
		try {
			connection = ConnectFactory.createConnection();
			
			String query = "SELECT id, first_name, last_name, cpf, gross_sales, commission_rate,base_salary FROM baseplus_commission_employee" ;
			st = connection.createStatement();
			ResultSet rs = st.executeQuery(query);
			
			while(rs.next()) {
				int id = rs.getInt("id");
				String firstName = rs.getString("first_name");
				String lastName = rs.getString("last_name");
				String cpf = Utils.formatarString("###.###.###-##", rs.getString("cpf"));
				double gross_sales = rs.getDouble("gross_sales");
				double commission_rate = rs.getDouble("commission_rate");
				double base_salary = rs.getDouble("base_salary");
				listPayable.add(new BasePlusCommissionEmployee(id, firstName,lastName,cpf,gross_sales,commission_rate,base_salary));
				
			}
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return null;
		}
		
		return listPayable;
	}

}
