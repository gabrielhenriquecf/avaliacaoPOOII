package br.edu.ifsuldeminas.model;

public interface Payable {
	
	double getPaymentAmount() ;

}
