package br.edu.ifsuldeminas.model;

public class Invoice implements Payable {
	
	 int id;
	 private String partNumber;
	 private String partDescription;
	 private int quantity;
	 private double pricePerItem;
	 
	public Invoice(String partNumber, String partDescription, int quantity, double pricePerItem) {
		super();
		this.partNumber = partNumber;
		this.partDescription = partDescription;
		this.quantity = quantity;
		this.pricePerItem = pricePerItem;
	}
	
	public Invoice(int id, String partNumber, String partDescription, int quantity, double pricePerItem) {
		super();
		this.partNumber = partNumber;
		this.partDescription = partDescription;
		this.quantity = quantity;
		this.pricePerItem = pricePerItem;
		this.id = id;
	}
	
	

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getPartNumber() {
		return partNumber;
	}

	public void setPartNumber(String partNumber) {
		this.partNumber = partNumber;
	}

	public String getPartDescription() {
		return partDescription;
	}

	public void setPartDescription(String partDescription) {
		this.partDescription = partDescription;
	}

	public int getQuantity() {
		return quantity;
	}

	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}

	public double getPricePerItem() {
		return pricePerItem;
	}

	public void setPricePerItem(double pricePerItem) {
		this.pricePerItem = pricePerItem;
	}


	@Override
	public double getPaymentAmount() {
			return getQuantity() * getPricePerItem();
	}
	
	
	@Override
	public String toString() {
		String s = String.format("Invoice numero: %s com a descrição: %s e quantidade %s com preço unitário %s", getPartNumber(),  getPartDescription(), getQuantity(), getPricePerItem());
		return s;
	}
	 
	 

}
