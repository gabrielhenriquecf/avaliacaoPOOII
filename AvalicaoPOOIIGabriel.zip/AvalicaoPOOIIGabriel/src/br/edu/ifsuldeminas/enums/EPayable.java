package br.edu.ifsuldeminas.enums;

public enum EPayable {
	
	SalariedEmployee,
	HourlyEmployee,
	CommissionEmployee,
	BasePlusCommissionEmployee,
	Invoice

}
