package br.edu.ifsuldeminas.message;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JSlider;
import javax.swing.JButton;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JTextField;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class FrameReceived extends JDialog  {

	private JPanel contentPane;
	private JTextField textFieldValorRecebido;
	private JLabel lblNewLabel;
	private MessageListener messageListener;
	private JButton btnNewButton;
	
	

	/**
	 * Create the frame.
	 */
	public FrameReceived() {
		setModal(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 450, 120);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);
		
		lblNewLabel = new JLabel("Valor Recebido:");
		lblNewLabel.setBounds(10, 48, 126, 14);
		contentPane.add(lblNewLabel);
		
		textFieldValorRecebido = new JTextField();
		textFieldValorRecebido.setBounds(106, 48, 114, 20);
		contentPane.add(textFieldValorRecebido);
		textFieldValorRecebido.setColumns(10);
		
		btnNewButton = new JButton("Devolver");
		btnNewButton.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				messageListener.sendMessage(textFieldValorRecebido.getText());
			}
		});
		btnNewButton.setBounds(324, 48, 89, 23);
		contentPane.add(btnNewButton);
		
	
		
	}
	
	public void addListener(MessageListener messageListener) {
		this.messageListener = messageListener;
		update();
	}
	
	public void update() {
		String received = messageListener.receiveMessage();
		textFieldValorRecebido.setText(received);
		
	}

	
	
	
}
