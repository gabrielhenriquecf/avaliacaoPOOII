package br.edu.ifsuldeminas.message;

public interface MessageListener {
	public String receiveMessage();
	public void sendMessage(String message);
}
