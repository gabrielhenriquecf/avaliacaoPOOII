package br.edu.ifsuldeminas.view.update;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import br.edu.ifsuldeminas.controller.ControllerPayable;
import br.edu.ifsuldeminas.model.SalariedEmployee;
import br.edu.ifsuldeminas.view.PayableMessage;

import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Component;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dialog.ModalityType;


public class SalariedEmployeeUpdateGUI extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldFirstName;
	private JTextField textFieldLastName;
	private JTextField textFieldCpf;
	private JTextField textFieldSalarioMensal;
	private JTextField textFieldId;
	
	private PayableMessage payableMessage = null;

	
	/**
	 * Create the frame.
	 */
	public SalariedEmployeeUpdateGUI() {
		setModalityType(ModalityType.APPLICATION_MODAL);

		setIconImage(Toolkit.getDefaultToolkit().getImage(SalariedEmployeeUpdateGUI.class.getResource("/img/Group2_Buyers_Dark.png")));
		setResizable(false);
		setTitle("Alterar Funcionário Assalariado");
		setBounds(100, 100, 572, 434);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("FirstName");
		
		textFieldFirstName = new JTextField();
		textFieldFirstName.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("LastName");
		
		textFieldLastName = new JTextField();
		textFieldLastName.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("CPF");
		
		textFieldCpf = new JTextField();
		textFieldCpf.setColumns(10);
		
		JLabel lblNewLabel_3 = new JLabel("Salário Semanal");
		
		textFieldSalarioMensal = new JTextField();
		textFieldSalarioMensal.setColumns(10);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/* recuperar os dados do JTextField */
				int id = Integer.parseInt(textFieldId.getText());
				String firstName = textFieldFirstName.getText();
				String lastName = textFieldLastName.getText();
				String cpf = textFieldCpf.getText();
				String salario = textFieldSalarioMensal.getText();
				
				double weeklySalary = 0;
				try {
					weeklySalary = Double.parseDouble(salario);
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Salário inválido");
					return;
				}
				
				/* Criar um objeto do tipo SalariedEmployee */
				SalariedEmployee salaried = new SalariedEmployee(id,firstName, lastName, cpf, weeklySalary);
				
				/* enviar para o controlador alterar os dados no banco */
				boolean resposta = ControllerPayable.getInstance().Update(salaried);

				if(resposta == true) {
				   JOptionPane.showMessageDialog(null,  salaried.toString() + "\nalterado com sucesso !", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null,  salaried.toString() + "\nOcorreu um erro !", "Erro", JOptionPane.ERROR_MESSAGE);
				}
				
						
			}
		});
		btnAlterar.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnAlterar.setIcon(null);
		btnAlterar.setPreferredSize(new Dimension(75, 23));
		btnAlterar.setMinimumSize(new Dimension(75, 23));
		btnAlterar.setMaximumSize(new Dimension(75, 23));
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancelar.setIcon(new ImageIcon(SalariedEmployeeUpdateGUI.class.getResource("/img/DeleteRed.png")));
		
		JLabel lblNewLabel_4 = new JLabel("Id");
		
		textFieldId = new JTextField();
		textFieldId.setEditable(false);
		textFieldId.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(10)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(textFieldLastName, GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
						.addComponent(textFieldCpf, GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
						.addComponent(textFieldSalarioMensal, GroupLayout.DEFAULT_SIZE, 510, Short.MAX_VALUE)
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel_4)
								.addComponent(textFieldId, GroupLayout.PREFERRED_SIZE, GroupLayout.DEFAULT_SIZE, GroupLayout.PREFERRED_SIZE))
							.addPreferredGap(ComponentPlacement.RELATED, 21, Short.MAX_VALUE)
							.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
								.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 119, GroupLayout.PREFERRED_SIZE)
								.addComponent(textFieldFirstName, GroupLayout.PREFERRED_SIZE, 403, GroupLayout.PREFERRED_SIZE))))
					.addContainerGap(10, Short.MAX_VALUE))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(202, Short.MAX_VALUE)
					.addComponent(btnAlterar, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(btnCancelar, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
					.addGap(10))
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 106, GroupLayout.PREFERRED_SIZE)
						.addComponent(lblNewLabel_3))
					.addGap(405))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap(21, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_4))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING, false)
						.addComponent(textFieldId)
						.addComponent(textFieldFirstName, GroupLayout.DEFAULT_SIZE, 31, Short.MAX_VALUE))
					.addGap(26)
					.addComponent(lblNewLabel_1)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(textFieldLastName, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
					.addGap(29)
					.addComponent(lblNewLabel_2)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textFieldCpf, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
					.addGap(30)
					.addComponent(lblNewLabel_3)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textFieldSalarioMensal, GroupLayout.PREFERRED_SIZE, 29, GroupLayout.PREFERRED_SIZE)
					.addGap(29)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAlterar, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnCancelar, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_contentPane.linkSize(SwingConstants.VERTICAL, new Component[] {btnAlterar, btnCancelar});
		gl_contentPane.linkSize(SwingConstants.HORIZONTAL, new Component[] {btnAlterar, btnCancelar});
		contentPane.setLayout(gl_contentPane);
		
				
	} //fim do método
	
	public void addPayableMessage(PayableMessage payableMessage) {
		this.payableMessage = payableMessage;
	}
	
	public void updateGUI() {
		SalariedEmployee salariedEmployee = (SalariedEmployee) payableMessage.receivePayable();
		textFieldId.setText(String.valueOf(salariedEmployee.getId()));
		textFieldFirstName.setText(salariedEmployee.getFirstName());
		textFieldLastName.setText(salariedEmployee.getLastName());
		textFieldCpf.setText(salariedEmployee.getCpf());
		textFieldSalarioMensal.setText(String.valueOf(salariedEmployee.getPaymentAmount()));
		
	}
	
}
