package br.edu.ifsuldeminas.view.update;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import br.edu.ifsuldeminas.controller.ControllerPayable;
import br.edu.ifsuldeminas.model.CommissionEmployee;
import br.edu.ifsuldeminas.model.HourlyEmployee;
import br.edu.ifsuldeminas.model.Invoice;
import br.edu.ifsuldeminas.model.SalariedEmployee;
import br.edu.ifsuldeminas.view.PayableMessage;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class InvoiceUpdateGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldPartNumber;
	private JTextField textFieldPartDescription;
	private JTextField textFieldQuantity;
	private JTextField textFieldPricePerItem;
	private JTextField textFieldId;
	private PayableMessage payableMessage;

	
	/**
	 * Create the frame.
	 */
	public InvoiceUpdateGUI() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(InvoiceUpdateGUI.class.getResource("/img/attached16x16.png")));
		setResizable(false);
		setTitle("Alterar Invoice");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 546, 379);
		contentPane = new JPanel();
		contentPane.setBorder(new EtchedBorder(EtchedBorder.RAISED, null, null));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("PartNumber");
		
		textFieldPartNumber = new JTextField();
		textFieldPartNumber.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("PartDescription");
		
		textFieldPartDescription = new JTextField();
		textFieldPartDescription.setColumns(10);
		
		JButton btnIncluir = new JButton("Alterar");
		btnIncluir.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/* recuperar os dados do JTextField */
				String partNumber = textFieldPartNumber.getText();
				String partDescription = textFieldPartDescription.getText();
			    String quantityString = textFieldQuantity.getText();
				String pricePerItemString = textFieldPricePerItem.getText();
				int id = Integer.parseInt(textFieldId.getText());
				
				int quantity = 0;
				try {
					quantity = Integer.parseInt(quantityString);
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Quantidade inválida");
					return;
				}
				
				double pricePerItem = 0;
				try {
					pricePerItem = Double.parseDouble(pricePerItemString);
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Preço por item inválido");
					return;
				}
				
				/* Criar um objeto do tipo Invoice */
				Invoice invoice = new Invoice(id,partNumber,partDescription,quantity,pricePerItem);
				
				boolean resposta = ControllerPayable.getInstance().Update(invoice);

				if(resposta == true) {
				   JOptionPane.showMessageDialog(null,  invoice.toString() + "\nalterado com sucesso !", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null,  invoice.toString() + "\nOcorreu um erro !", "Erro", JOptionPane.ERROR_MESSAGE);
				}
				
				
			}
		});
		btnIncluir.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnIncluir.setIcon(new ImageIcon(InvoiceUpdateGUI.class.getResource("/img/add.png")));
		btnIncluir.setPreferredSize(new Dimension(75, 23));
		btnIncluir.setMinimumSize(new Dimension(75, 23));
		btnIncluir.setMaximumSize(new Dimension(75, 23));
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				dispose();
			}
			
		});
		btnCancelar.setIcon(new ImageIcon(InvoiceUpdateGUI.class.getResource("/img/DeleteRed.png")));
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JLabel lblNewLabel_2 = new JLabel("Id");
		
		textFieldId = new JTextField();
		textFieldId.setEditable(false);
		textFieldId.setEnabled(false);
		textFieldId.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE)
							.addGap(411))
						.addGroup(Alignment.TRAILING, gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addComponent(btnIncluir, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE)
									.addGap(18)
									.addComponent(btnCancelar, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE))
								.addComponent(panel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)
								.addComponent(textFieldPartDescription, GroupLayout.PREFERRED_SIZE, 505, GroupLayout.PREFERRED_SIZE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(lblNewLabel_2, GroupLayout.DEFAULT_SIZE, 46, Short.MAX_VALUE)
											.addGap(119))
										.addGroup(gl_contentPane.createSequentialGroup()
											.addComponent(textFieldId, GroupLayout.PREFERRED_SIZE, 152, GroupLayout.PREFERRED_SIZE)
											.addPreferredGap(ComponentPlacement.RELATED)))
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 119, GroupLayout.PREFERRED_SIZE)
										.addComponent(textFieldPartNumber, GroupLayout.PREFERRED_SIZE, 343, GroupLayout.PREFERRED_SIZE))))
							.addGap(18))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(21)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_2))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(textFieldId, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE)
							.addGap(18)
							.addComponent(lblNewLabel_1))
						.addComponent(textFieldPartNumber, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE))
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(textFieldPartDescription, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
					.addGap(29)
					.addComponent(panel, GroupLayout.PREFERRED_SIZE, 93, GroupLayout.PREFERRED_SIZE)
					.addPreferredGap(ComponentPlacement.RELATED, 28, Short.MAX_VALUE)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnCancelar, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnIncluir, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_contentPane.linkSize(SwingConstants.VERTICAL, new Component[] {textFieldPartNumber, textFieldId});
		gl_contentPane.linkSize(SwingConstants.VERTICAL, new Component[] {btnIncluir, btnCancelar});
		gl_contentPane.linkSize(SwingConstants.HORIZONTAL, new Component[] {btnIncluir, btnCancelar});
		panel.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Quantity");
		lblNewLabel_3.setBounds(10, 11, 105, 14);
		panel.add(lblNewLabel_3);
		
		textFieldQuantity = new JTextField();
		textFieldQuantity.setBounds(10, 36, 232, 31);
		panel.add(textFieldQuantity);
		textFieldQuantity.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Price Per Item");
		lblNewLabel_4.setBounds(276, 11, 177, 14);
		panel.add(lblNewLabel_4);
		
		textFieldPricePerItem = new JTextField();
		textFieldPricePerItem.setBounds(276, 36, 218, 31);
		panel.add(textFieldPricePerItem);
		textFieldPricePerItem.setColumns(10);
		contentPane.setLayout(gl_contentPane);
	} //fim do método
	
	public void addPayableMessage(PayableMessage payableMessage) {
		this.payableMessage = payableMessage;
	}
	
	public void updateGUI() {
		Invoice invoice = (Invoice) payableMessage.receivePayable();
		textFieldId.setText(String.valueOf(invoice.getId()));
		textFieldPartDescription.setText(invoice.getPartDescription());
		textFieldPartNumber.setText(invoice.getPartNumber());
		textFieldPricePerItem.setText(String.valueOf(invoice.getPricePerItem()));
		textFieldQuantity.setText(String.valueOf(invoice.getQuantity()));
	
		
	}
	
}
