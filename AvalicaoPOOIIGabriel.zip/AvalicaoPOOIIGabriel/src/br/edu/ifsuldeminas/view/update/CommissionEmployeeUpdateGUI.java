package br.edu.ifsuldeminas.view.update;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.TitledBorder;

import br.edu.ifsuldeminas.controller.ControllerPayable;
import br.edu.ifsuldeminas.model.CommissionEmployee;
import br.edu.ifsuldeminas.model.HourlyEmployee;
import br.edu.ifsuldeminas.model.SalariedEmployee;
import br.edu.ifsuldeminas.view.PayableMessage;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;

public class CommissionEmployeeUpdateGUI extends JFrame {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldFirstName;
	private JTextField textFieldLastName;
	private JTextField textFieldCpf;
	private JTextField textFieldVendaTotal;
	private JTextField textFieldTaxaComissao;
	private PayableMessage payableMessage;
	private JTextField textFieldId;

	
	/**
	 * Create the frame.
	 */
	public CommissionEmployeeUpdateGUI() {
		setIconImage(Toolkit.getDefaultToolkit().getImage(CommissionEmployeeUpdateGUI.class.getResource("/img/Group2_Buyers_Dark.png")));
		setResizable(false);
		setTitle("Alterar Funcionário Comissionado");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 546, 459);
		contentPane = new JPanel();
		contentPane.setBorder(new EtchedBorder(EtchedBorder.RAISED, null, null));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Nome");
		
		textFieldFirstName = new JTextField();
		textFieldFirstName.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Sobrenome");
		
		textFieldLastName = new JTextField();
		textFieldLastName.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("CPF");
		
		textFieldCpf = new JTextField();
		textFieldCpf.setColumns(10);
		
		JButton btnAlterar = new JButton("Alterar");
		btnAlterar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				/* recuperar os dados do JTextField */
				String firstName = textFieldFirstName.getText();
				String lastName = textFieldLastName.getText();
				String cpf = textFieldCpf.getText();
				String vendaTotal = textFieldVendaTotal.getText();
				String taxaComissao = textFieldTaxaComissao.getText();
				String id = textFieldId.getText();
				
				double grossSales = 0;
				try {
					grossSales = Double.parseDouble(vendaTotal);
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Venda inválida");
					return;
				}
				
				double commissionRate = 0;
				try {
					commissionRate = Double.parseDouble(taxaComissao);
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Taxa de Comissão inválida");
					return;
				}
				
				int iid = Integer.parseInt(id);
				
				/* Criar um objeto do tipo CommissionEmployee */
				CommissionEmployee salaried = new CommissionEmployee(iid,firstName,lastName,cpf,grossSales,commissionRate);
				
				/* Adicionar na minha Lista */
				boolean resposta = ControllerPayable.getInstance().Update(salaried);
					
				if(resposta == true) {
					JOptionPane.showMessageDialog(null,  salaried.toString() + "\nalterado com sucesso !", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null,  salaried.toString() + "\nErro na alteração", "Erro", JOptionPane.ERROR_MESSAGE);
				}
				
			
			}
		});
		btnAlterar.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnAlterar.setIcon(null);
		btnAlterar.setPreferredSize(new Dimension(75, 23));
		btnAlterar.setMinimumSize(new Dimension(75, 23));
		btnAlterar.setMaximumSize(new Dimension(75, 23));
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
			
		});
		btnCancelar.setIcon(new ImageIcon(CommissionEmployeeUpdateGUI.class.getResource("/img/DeleteRed.png")));
		
		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JLabel lblNewLabel_5 = new JLabel("Id");
		
		textFieldId = new JTextField();
		textFieldId.setEnabled(false);
		textFieldId.setColumns(10);
		GroupLayout gl_contentPane = new GroupLayout(contentPane);
		gl_contentPane.setHorizontalGroup(
			gl_contentPane.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addContainerGap()
					.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
						.addGroup(gl_contentPane.createSequentialGroup()
							.addComponent(btnAlterar, GroupLayout.PREFERRED_SIZE, 154, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED)
							.addComponent(btnCancelar, GroupLayout.PREFERRED_SIZE, 148, GroupLayout.PREFERRED_SIZE)
							.addGap(14))
						.addGroup(gl_contentPane.createSequentialGroup()
							.addGroup(gl_contentPane.createParallelGroup(Alignment.TRAILING)
								.addComponent(panel, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)
								.addComponent(textFieldCpf, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)
								.addComponent(textFieldLastName, Alignment.LEADING, GroupLayout.DEFAULT_SIZE, 508, Short.MAX_VALUE)
								.addGroup(gl_contentPane.createSequentialGroup()
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel_5)
										.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE)
										.addComponent(lblNewLabel_2, GroupLayout.PREFERRED_SIZE, 106, GroupLayout.PREFERRED_SIZE)
										.addComponent(textFieldId, GroupLayout.PREFERRED_SIZE, 115, GroupLayout.PREFERRED_SIZE))
									.addPreferredGap(ComponentPlacement.RELATED, 15, Short.MAX_VALUE)
									.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
										.addComponent(lblNewLabel, GroupLayout.PREFERRED_SIZE, 119, GroupLayout.PREFERRED_SIZE)
										.addComponent(textFieldFirstName, GroupLayout.PREFERRED_SIZE, 378, GroupLayout.PREFERRED_SIZE))))
							.addGap(18))))
		);
		gl_contentPane.setVerticalGroup(
			gl_contentPane.createParallelGroup(Alignment.TRAILING)
				.addGroup(gl_contentPane.createSequentialGroup()
					.addGap(21)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(lblNewLabel)
						.addComponent(lblNewLabel_5))
					.addPreferredGap(ComponentPlacement.RELATED)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.LEADING)
						.addComponent(textFieldFirstName)
						.addComponent(textFieldId, GroupLayout.PREFERRED_SIZE, 28, GroupLayout.PREFERRED_SIZE))
					.addGap(29)
					.addComponent(lblNewLabel_1)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addComponent(textFieldLastName, GroupLayout.PREFERRED_SIZE, 33, GroupLayout.PREFERRED_SIZE)
					.addGap(29)
					.addComponent(lblNewLabel_2)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(textFieldCpf, GroupLayout.PREFERRED_SIZE, 31, GroupLayout.PREFERRED_SIZE)
					.addGap(18)
					.addComponent(panel, GroupLayout.DEFAULT_SIZE, 93, Short.MAX_VALUE)
					.addGap(18)
					.addGroup(gl_contentPane.createParallelGroup(Alignment.BASELINE)
						.addComponent(btnAlterar, GroupLayout.PREFERRED_SIZE, 40, GroupLayout.PREFERRED_SIZE)
						.addComponent(btnCancelar, GroupLayout.PREFERRED_SIZE, 39, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		gl_contentPane.linkSize(SwingConstants.VERTICAL, new Component[] {btnAlterar, btnCancelar});
		gl_contentPane.linkSize(SwingConstants.HORIZONTAL, new Component[] {btnAlterar, btnCancelar});
		panel.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Venda total");
		lblNewLabel_3.setBounds(27, 11, 105, 14);
		panel.add(lblNewLabel_3);
		
		textFieldVendaTotal = new JTextField();
		textFieldVendaTotal.setBounds(24, 38, 218, 32);
		panel.add(textFieldVendaTotal);
		textFieldVendaTotal.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Taxa de Comissão");
		lblNewLabel_4.setBounds(266, 11, 105, 14);
		panel.add(lblNewLabel_4);
		
		textFieldTaxaComissao = new JTextField();
		textFieldTaxaComissao.setBounds(266, 38, 218, 32);
		panel.add(textFieldTaxaComissao);
		textFieldTaxaComissao.setColumns(10);
		contentPane.setLayout(gl_contentPane);
	} //fim do método
	
	/* métodos para permitir a troca de mensagem entre frames */
	public void addPayableMessage(PayableMessage payableMessage) {
		this.payableMessage = payableMessage;
	}
	
	public void updateGUI() {
		CommissionEmployee salariedEmployee = (CommissionEmployee) payableMessage.receivePayable();
		textFieldId.setText(String.valueOf(salariedEmployee.getId()));
		textFieldFirstName.setText(salariedEmployee.getFirstName());
		textFieldLastName.setText(salariedEmployee.getLastName());
		textFieldCpf.setText(salariedEmployee.getCpf());
		textFieldTaxaComissao.setText(String.valueOf(salariedEmployee.getCommissionRate()));
		textFieldVendaTotal.setText(String.valueOf(salariedEmployee.getGrossSales()));
		
	}
	
}
