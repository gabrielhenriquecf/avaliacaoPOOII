package br.edu.ifsuldeminas.view.update;

import java.awt.BorderLayout;
import java.awt.EventQueue;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.BevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.JTextField;
import javax.swing.JButton;
import javax.swing.DefaultComboBoxModel;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.event.ItemListener;
import java.util.List;
import java.awt.event.ItemEvent;
import javax.swing.event.CaretListener;

import br.edu.ifsuldeminas.controller.ControllerPayable;
import br.edu.ifsuldeminas.dao.PayableDao;
import br.edu.ifsuldeminas.dao.employee.BasePlusCommissionEmployeeDaoImpl;
import br.edu.ifsuldeminas.dao.employee.CommissionEmployeeDaoImpl;
import br.edu.ifsuldeminas.dao.employee.HourlyEmployeeDaoImpl;
import br.edu.ifsuldeminas.dao.employee.SalariedEmployeeDaoImpl;
import br.edu.ifsuldeminas.dao.invoice.InvoiceDaoImpl;
import br.edu.ifsuldeminas.enums.EPayable;
import br.edu.ifsuldeminas.model.BasePlusCommissionEmployee;
import br.edu.ifsuldeminas.model.CommissionEmployee;
import br.edu.ifsuldeminas.model.HourlyEmployee;
import br.edu.ifsuldeminas.model.Payable;
import br.edu.ifsuldeminas.model.SalariedEmployee;
import br.edu.ifsuldeminas.view.PayableMessage;
import br.edu.ifsuldeminas.view.SearchMessageListener;
import br.edu.ifsuldeminas.view.SearchPayableGUI;

import javax.swing.event.CaretEvent;
import javax.swing.UIManager;
import java.awt.Color;
import java.awt.Dialog.ModalityType;

public class FilterUpdateEmployee extends JFrame {

	private JPanel contentPane;
	private JTextField textFieldId;
	private JButton btnPesquisa;
	private JButton btnOK;
	private JButton btnCancelar;
	private JComboBox comboBox;

	/* minhas variaveis */
	private Payable payable = null;
	private List<Payable> listPayable;

	/**
	 * Launch the application.
	 */
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					FilterUpdateEmployee frame = new FilterUpdateEmployee();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}

	/**
	 * Create the frame.
	 */
	public FilterUpdateEmployee() {
		setResizable(false);
		setTitle("Filtro para alteração");
		setBounds(100, 100, 450, 282);
		contentPane = new JPanel();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setContentPane(contentPane);
		contentPane.setLayout(null);

		JLabel lblNewLabel = new JLabel("Selecione o tipo de funcionário e depois o Id para alteração");
		lblNewLabel.setBounds(10, 11, 406, 14);
		contentPane.add(lblNewLabel);

		JPanel panel = new JPanel();
		panel.setBorder(new TitledBorder(UIManager.getBorder("TitledBorder.border"), "", TitledBorder.LEADING, TitledBorder.TOP, null, new Color(0, 0, 0)));
		panel.setBounds(10, 44, 413, 148);
		contentPane.add(panel);
		panel.setLayout(null);

		comboBox = new JComboBox();
		comboBox.addItemListener(new ItemListener() {
			public void itemStateChanged(ItemEvent e) {

				if(! comboBox.getSelectedItem().equals("Selecione")) {
					textFieldId.setEnabled(true);
					btnPesquisa.setEnabled(true);

				} else {
					textFieldId.setEnabled(false);
					btnPesquisa.setEnabled(false);
				}

			}
		});

		comboBox.setModel(new DefaultComboBoxModel(new String[] {"Selecione", "SalariedEmployee", "HourlyEmployee", "CommissionEmployee", "BasePlusCommissionEmployee"}));
		comboBox.setBounds(25, 37, 360, 30);
		panel.add(comboBox);

		JLabel lblNewLabel_1 = new JLabel("Tipo de Funcionário");
		lblNewLabel_1.setBounds(25, 12, 132, 14);
		panel.add(lblNewLabel_1);

		JLabel lblNewLabel_2 = new JLabel("Id para alterar");
		lblNewLabel_2.setBounds(25, 85, 164, 14);
		panel.add(lblNewLabel_2);

		textFieldId = new JTextField();
		textFieldId.addCaretListener(new CaretListener() { 
			public void caretUpdate(CaretEvent e) {
				if(textFieldId.getText().length() > 0) {
					btnOK.setEnabled(true);
				} else {
					btnOK.setEnabled(false);
				}
			}
		});
		textFieldId.setEnabled(false);
		textFieldId.setBounds(25, 108, 224, 27);
		panel.add(textFieldId);
		textFieldId.setColumns(10);

		btnPesquisa = new JButton("Pesquisa");
		btnPesquisa.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				EPayable tipo = EPayable.valueOf((String) comboBox.getSelectedItem());
				//switch(tipo) {

				//case SalariedEmployee:

				/* Procurar no banco se o Id informado existe */
				listPayable =  ControllerPayable.getInstance().ListByType(tipo);

				/* cria o interface de procura e registro o listener para enviar a lista */

				MySearchMessage mySearchMessage = new MySearchMessage();
				SearchPayableGUI search = new SearchPayableGUI();
				search.addSearchListener(mySearchMessage);
				search.updateTable();
				search.setLocationRelativeTo(null);
				search.setVisible(true);


				//	break;



				//}

			}

		});
		btnPesquisa.setEnabled(false);
		btnPesquisa.setBounds(259, 108, 126, 27);
		panel.add(btnPesquisa);

		btnOK = new JButton("Prosseguir");
		btnOK.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {

				EPayable tipo = EPayable.valueOf((String) comboBox.getSelectedItem());
				int id = Integer.parseInt(textFieldId.getText());

				//* troquei o switch por um if/elseif *//


				if(tipo ==  EPayable.SalariedEmployee) {

					/* Procurar no banco se o Id informado existe */
					SalariedEmployee resposta = (SalariedEmployee) ControllerPayable.getInstance().getPayable(id, tipo);

					if(resposta == null) {
						/* não existe o id no banco */
						JOptionPane.showMessageDialog(null, "Id não localizado","Problema",JOptionPane.WARNING_MESSAGE);
						return;
					}

					payable = resposta; //depois

					dispose();

					SalariedEmployeeUpdateGUI gui = new SalariedEmployeeUpdateGUI();

					MyPayableMessage my = new MyPayableMessage();

					gui.addPayableMessage(my);
					gui.updateGUI();

					gui.setLocationRelativeTo(null);
					gui.setVisible(true);


				} else if (tipo == EPayable.HourlyEmployee) {

					/* Procurar no banco se o Id informado existe */
					HourlyEmployee resposta = (HourlyEmployee) ControllerPayable.getInstance().getPayable(id, tipo);

					if(resposta == null) {
						/* não existe o id no banco */
						JOptionPane.showMessageDialog(null, "Id não localizado","Problema",JOptionPane.WARNING_MESSAGE);
						return;
					}

					payable = resposta; //depois

					dispose();

					HourlyEmployeeUpdateGUI gui = new HourlyEmployeeUpdateGUI();

					MyPayableMessage my = new MyPayableMessage();

					gui.addPayableMessage(my);
					gui.updateGUI();

					gui.setLocationRelativeTo(null);
					gui.setVisible(true);
				
				} else if (tipo == EPayable.CommissionEmployee) {

					/* Procurar no banco se o Id informado existe */
					CommissionEmployee resposta = (CommissionEmployee) ControllerPayable.getInstance().getPayable(id, tipo);

					if(resposta == null) {
						/* não existe o id no banco */
						JOptionPane.showMessageDialog(null, "Id não localizado","Problema",JOptionPane.WARNING_MESSAGE);
						return;
					}

					payable = resposta; //depois

					dispose();

					CommissionEmployeeUpdateGUI gui = new CommissionEmployeeUpdateGUI();

					MyPayableMessage my = new MyPayableMessage();

					gui.addPayableMessage(my);
					gui.updateGUI();

					gui.setLocationRelativeTo(null);
					gui.setVisible(true);
				
				} else if (tipo == EPayable.BasePlusCommissionEmployee) {

					/* Procurar no banco se o Id informado existe */
					BasePlusCommissionEmployee resposta = (BasePlusCommissionEmployee) ControllerPayable.getInstance().getPayable(id, tipo);

					if(resposta == null) {
						/* não existe o id no banco */
						JOptionPane.showMessageDialog(null, "Id não localizado","Problema",JOptionPane.WARNING_MESSAGE);
						return;
					}

					payable = resposta; //depois

					dispose();

					BasePlusCommissionEmployeeUpdateGUI gui = new BasePlusCommissionEmployeeUpdateGUI();

					MyPayableMessage my = new MyPayableMessage();

					gui.addPayableMessage(my);
					gui.updateGUI();

					gui.setLocationRelativeTo(null);
					gui.setVisible(true);
				
				}
			}
		});
		btnOK.setEnabled(false);
		btnOK.setBounds(167, 203, 127, 34);
		contentPane.add(btnOK);

		btnCancelar = new JButton("Cancelar");
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancelar.setBounds(315, 203, 108, 34);
		contentPane.add(btnCancelar);
	}

	private class MyPayableMessage implements PayableMessage {

		@Override
		public Payable receivePayable() {
			return payable;
		}

	}


	private class MySearchMessage implements SearchMessageListener {

		@Override
		public List<Payable> receiveList() {
			return listPayable;
		}

		@Override
		public void sendIdentifier(int id) {
			String identifier = String.valueOf(id);
			textFieldId.setText(identifier);			
		}

	}


}


