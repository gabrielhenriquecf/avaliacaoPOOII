package br.edu.ifsuldeminas.view;

import java.util.List;

import br.edu.ifsuldeminas.model.Payable;

public interface SearchMessageListener {
	public List<Payable> receiveList();
	public void sendIdentifier(int id);
}
