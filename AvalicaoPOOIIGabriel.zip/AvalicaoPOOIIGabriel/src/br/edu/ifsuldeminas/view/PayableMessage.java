package br.edu.ifsuldeminas.view;

import br.edu.ifsuldeminas.model.Payable;

public interface PayableMessage {
	
	public Payable receivePayable();

}
