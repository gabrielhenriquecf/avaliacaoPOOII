package br.edu.ifsuldeminas.view.delete;

import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;
import java.awt.Toolkit;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import javax.swing.JLabel;
import javax.swing.JOptionPane;
import javax.swing.JTextField;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JButton;
import javax.swing.JDialog;

import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.SwingConstants;
import java.awt.Component;
import javax.swing.border.BevelBorder;
import javax.swing.border.EtchedBorder;
import javax.swing.border.SoftBevelBorder;
import javax.swing.border.TitledBorder;
import javax.swing.plaf.metal.MetalBorders.TextFieldBorder;

import br.edu.ifsuldeminas.controller.ControllerPayable;
import br.edu.ifsuldeminas.model.BasePlusCommissionEmployee;
import br.edu.ifsuldeminas.model.CommissionEmployee;
import br.edu.ifsuldeminas.view.PayableMessage;

import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.awt.Dialog.ModalityType;

public class BasePlusCommissionEmployeeDeleteGUI extends JDialog {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JPanel contentPane;
	private JTextField textFieldFirstName;
	private JTextField textFieldLastName;
	private JTextField textFieldCpf;
	private JTextField textFieldVendaTotal;
	private JTextField textFieldTaxaComissao;
	private JTextField textFieldSalarioBase;
	private JTextField textFieldId;
	private PayableMessage payableMessage;

	
	/**
	 * Create the frame.
	 */
	public BasePlusCommissionEmployeeDeleteGUI() {
		setModalityType(ModalityType.APPLICATION_MODAL);
		setIconImage(Toolkit.getDefaultToolkit().getImage(BasePlusCommissionEmployeeDeleteGUI.class.getResource("/img/Group2_Buyers_Dark.png")));
		setResizable(false);
		setTitle("Apagar Funcionário Comissionado e Salário Base");
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setBounds(100, 100, 541, 611);
		contentPane = new JPanel();
		contentPane.setBorder(new EtchedBorder(EtchedBorder.RAISED, null, null));
		setContentPane(contentPane);
		
		JLabel lblNewLabel = new JLabel("Nome");
		lblNewLabel.setBounds(104, 42, 98, 14);
		
		textFieldFirstName = new JTextField();
		textFieldFirstName.setBounds(104, 67, 413, 31);
		textFieldFirstName.setEditable(false);
		textFieldFirstName.setColumns(10);
		
		JLabel lblNewLabel_1 = new JLabel("Sobrenome");
		lblNewLabel_1.setBounds(12, 124, 515, 14);
		
		textFieldLastName = new JTextField();
		textFieldLastName.setBounds(12, 149, 504, 33);
		textFieldLastName.setEditable(false);
		textFieldLastName.setColumns(10);
		
		JLabel lblNewLabel_2 = new JLabel("CPF");
		lblNewLabel_2.setBounds(12, 211, 56, 14);
		
		textFieldCpf = new JTextField();
		textFieldCpf.setBounds(12, 231, 504, 31);
		textFieldCpf.setEditable(false);
		textFieldCpf.setColumns(10);
		
		JButton btnDeletar = new JButton("Apagar");
		btnDeletar.setBounds(190, 517, 154, 40);
		btnDeletar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				
				/* recuperar os dados do JTextField */
				String firstName = textFieldFirstName.getText();
				String lastName = textFieldLastName.getText();
				String cpf = textFieldCpf.getText();
				String vendaTotal = textFieldVendaTotal.getText();
				String taxaComissao = textFieldTaxaComissao.getText();
				String salarioBase = textFieldSalarioBase.getText();
				int id = Integer.parseInt(textFieldId.getText());
				
				double grossSales = 0;
				try {
					grossSales = Double.parseDouble(vendaTotal);
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Venda inválida");
					return;
				}
				
				double commissionRate = 0;
				try {
					commissionRate = Double.parseDouble(taxaComissao);
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Taxa de Comissão inválida");
					return;
				}
				
				double baseSalary = 0;
				try {
					baseSalary = Double.parseDouble(salarioBase);
				} catch(NumberFormatException e1) {
					JOptionPane.showMessageDialog(null, "Salário base inválido");
					return;
				}
				
				 int input = JOptionPane.showConfirmDialog(null, "Confirma a exclusão do funcionário: " + firstName + " " + lastName , "Atenção !", JOptionPane.YES_NO_OPTION);
				    
				 if(input == JOptionPane.NO_OPTION) {
				    	return;
				 }
				
				/* Criar um objeto do tipo BasePlusCommissionEmployee */
				BasePlusCommissionEmployee salaried = new BasePlusCommissionEmployee(id,firstName,lastName,cpf,grossSales,commissionRate,baseSalary);
				
				/* Alterar na minha Lista */
				boolean resposta = ControllerPayable.getInstance().Delete(salaried);
			
				if(resposta == true) {
					JOptionPane.showMessageDialog(null,  salaried.toString() + "\napagado com sucesso !", "Sucesso", JOptionPane.INFORMATION_MESSAGE);
				} else {
					JOptionPane.showMessageDialog(null,  salaried.toString() + "\nErro ao apagar registro", "Erro", JOptionPane.ERROR_MESSAGE);
				}
				
				dispose();
			}
			
		});
		btnDeletar.setHorizontalTextPosition(SwingConstants.RIGHT);
		btnDeletar.setIcon(new ImageIcon(BasePlusCommissionEmployeeDeleteGUI.class.getResource("/img/DeleteRed.png")));
		btnDeletar.setPreferredSize(new Dimension(75, 23));
		btnDeletar.setMinimumSize(new Dimension(75, 23));
		btnDeletar.setMaximumSize(new Dimension(75, 23));
		
		JButton btnCancelar = new JButton("Cancelar");
		btnCancelar.setBounds(362, 517, 154, 40);
		btnCancelar.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				dispose();
			}
		});
		btnCancelar.setIcon(null);
		
		JPanel panel = new JPanel();
		panel.setBounds(12, 280, 504, 219);
		panel.setBorder(new TitledBorder(null, "", TitledBorder.LEADING, TitledBorder.TOP, null, null));
		
		JLabel lblNewLabel_7 = new JLabel("Id");
		lblNewLabel_7.setBounds(12, 42, 21, 14);
		
		textFieldId = new JTextField();
		textFieldId.setBounds(12, 67, 86, 31);
		textFieldId.setEnabled(false);
		textFieldId.setEditable(false);
		textFieldId.setColumns(10);
		panel.setLayout(null);
		
		JLabel lblNewLabel_3 = new JLabel("Venda total");
		lblNewLabel_3.setBounds(24, 12, 105, 14);
		panel.add(lblNewLabel_3);
		
		textFieldVendaTotal = new JTextField();
		textFieldVendaTotal.setEditable(false);
		textFieldVendaTotal.setBounds(24, 30, 334, 33);
		panel.add(textFieldVendaTotal);
		textFieldVendaTotal.setColumns(10);
		
		JLabel lblNewLabel_4 = new JLabel("Taxa de Comissão");
		lblNewLabel_4.setBounds(24, 75, 105, 14);
		panel.add(lblNewLabel_4);
		
		textFieldTaxaComissao = new JTextField();
		textFieldTaxaComissao.setEditable(false);
		textFieldTaxaComissao.setBounds(24, 93, 334, 33);
		panel.add(textFieldTaxaComissao);
		textFieldTaxaComissao.setColumns(10);
		
		JLabel lblNewLabel_5 = new JLabel("Salário Base");
		lblNewLabel_5.setBounds(24, 138, 173, 14);
		panel.add(lblNewLabel_5);
		
		textFieldSalarioBase = new JTextField();
		textFieldSalarioBase.setEditable(false);
		textFieldSalarioBase.setBounds(24, 156, 334, 33);
		panel.add(textFieldSalarioBase);
		textFieldSalarioBase.setColumns(10);
		
		JLabel lblNewLabel_6 = new JLabel("");
		lblNewLabel_6.setIcon(new ImageIcon(BasePlusCommissionEmployeeDeleteGUI.class.getResource("/img/Group2_Employees_Dark.png")));
		lblNewLabel_6.setBounds(416, 12, 48, 88);
		panel.add(lblNewLabel_6);
		contentPane.setLayout(null);
		contentPane.add(btnDeletar);
		contentPane.add(btnCancelar);
		contentPane.add(lblNewLabel_7);
		contentPane.add(textFieldId);
		contentPane.add(lblNewLabel);
		contentPane.add(textFieldFirstName);
		contentPane.add(panel);
		contentPane.add(textFieldCpf);
		contentPane.add(textFieldLastName);
		contentPane.add(lblNewLabel_2);
		contentPane.add(lblNewLabel_1);
	} //fim do método
	
	/* métodos para permitir a troca de mensagem entre frames */
	public void addPayableMessage(PayableMessage payableMessage) {
		this.payableMessage = payableMessage;
	}
	
	public void updateGUI() {
		BasePlusCommissionEmployee salariedEmployee = (BasePlusCommissionEmployee) payableMessage.receivePayable();
		textFieldId.setText(String.valueOf(salariedEmployee.getId()));
		textFieldFirstName.setText(salariedEmployee.getFirstName());
		textFieldLastName.setText(salariedEmployee.getLastName());
		textFieldCpf.setText(salariedEmployee.getCpf());
		textFieldTaxaComissao.setText(String.valueOf(salariedEmployee.getCommissionRate()));
		textFieldVendaTotal.setText(String.valueOf(salariedEmployee.getGrossSales()));
		textFieldSalarioBase.setText(String.valueOf(salariedEmployee.getBaseSalary()));
		
	}
}
